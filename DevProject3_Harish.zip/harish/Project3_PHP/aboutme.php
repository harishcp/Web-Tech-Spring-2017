<!DOCTYPE html>
<html>
<head>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("button").click(function(){
       
        $("#div2").fadeIn("slow");
       
    });
});
</script>
<style>
	body{
		
				width:100%; height:900px; background-image: url(BGImage.jpg); background-repeat:no-repeat; background-size: 1700px 1000px;"
			}

			p{
				text-align:justify;
				color:#212621;
				font-size:25px;
		}

</style>

</head>
<body>

<button style="margin-left:50%;"><i><b>Click me for details</b></i></button><br><br>

<div id="div2" style="margin-left:80%; width:80px;height:120px;display:none;margin-left:30%;
				margin-top:160px;
				border:1px; 
				width:800px; 	
				height:700px;"><i><b><u>About Me</i></b></u>
<p><i>
Hello, I am Harish currently pursuing MS in Marist. I have an experience of 5 years in IT industry with Testing and Agile. I am proficient in .NET programming and also C,C++.
</i></p> 
</div>
</body>
</html>