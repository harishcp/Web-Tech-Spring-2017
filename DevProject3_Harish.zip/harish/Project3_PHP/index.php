<!DOCTYPE html>
<html>
<head>
	
	<title>My Resume</title>
	<meta charset="UTF-8">

	<script src="jquery-3.1.1.js"></script>
	
	<style>
	footer {
	padding: 1px;
    color: white;
    background-color: #352729;
    text-align: center;
    position:fixed;
    right:0px;
    bottom:0px;
    width:100%;
}
	div.two{
		border:1px solid black; 
		width:80px; 
		height:33px; 
		background-color:#4CAF50;
		margin-top:20px;
		margin-left:1770px;
		text-align:center;
		padding-top:13px;
		font-size:20px;
		color:white;
	}
		div.three{
		border:1px solid black; 
		width:80px; 
		height:33px; 
		background-color:#4CAF50;
		margin-left:1770px;
		text-align:center;
		padding-top:13px;
		font-size:20px;
		color:white;
	}
	.button {
		background-color: #4CAF50;
		border: none; 
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 15px;
		cursor: pointer;
		}
	h1{
		margin-top:0px;
		color:#40156d; 
		font-size: 50px;
		text-align: center;
		}
	h2{
		margin-top:0px;
		color:#40156d; 
		font-size: 50px;
		text-align: center;
		}
	img {
    margin-left: 40%;
    margin-top: 0%;
}
.sidenav {
    height: 800px;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #e01123;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
	margin-top:7px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s
}

.sidenav a:hover, .offcanvas a:focus{
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

#main {
    transition: margin-left;
    padding: 16px;
}

@media screen and (max-height: 650px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

	
	</style>
<script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
<link rel="stylesheet" href="jquery-ui.css">
</head>

<script>

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function checkCookie() {
    var user = getCookie("username");
    if (user != "") {
        alert("Welcome again " + user);
    } else {
        user = prompt("Please enter your name:", "");
        if (user != "" && user != null) {
            setCookie("username", user, 365);
        }
    }
}

</script>

<script src="../js/jquery.js"></script>
<script>
	$(document).ready(
		function(){
			$(".pop1").on('click', function(){
				$(".box").slideDown("slow");
			});

			$(".close").on('click', function(){
				$(".box").slideUp("slow");
		});
	});
</script>

<style>
	.box{
		background-color: #cc304d;
		height:200px;
		width:400px;
		position: absolute;
		left:35%;
		top:30%;
		display:none;
		text-align: center;
		border: 2px solid black;
	}
	.close{
		float:right;
	}
	#draggable {
    width: 100px;
    height: 100px;
    background: #ccc;
    padding-left: 20px;
    left: 25px;
    top: 30px;
  }
  #droppable {
    position: absolute;
    left: 250px;
    top: 40px;
    width: 125px;
    height: 125px;
    background: #999;
    color: red;
    padding: 10px;
  }
</style>
<body onload= "checkCookie()">

	<div  style = "width:100%; height:900px; background-image: url(BGImage.jpg); background-repeat:no-repeat; background-size: 1700px 1000px;">
		<div id="mySidenav" class="sidenav">
			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<a href="aboutme.php">AboutMe</a>
			<a href="ContactInfo.php">ContactInfo</a>
			<a class="pop1" href="#">Download Resume</a>
		</div>
			<div id="main">
				<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>
			</div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96369037-1', 'auto');
  ga('send', 'pageview');

</script>


	<script>
			function openNav() {
			document.getElementById("mySidenav").style.width = "250px";
			document.getElementById("main").style.marginLeft = "250px";
		}

			function closeNav() {
			document.getElementById("mySidenav").style.width = "0";
			document.getElementById("main").style.marginLeft= "0";
		}
	</script>
 
		<h1><i><u>
		Harish's Resume</u>
		<br></h1>
		<h2>A Software Engineer by Profession</i></font>
		</h2>
<div>

<img src="ha.jpg" alt="My Pic" width="304px" height="228px">

</div>
<a href="https://www.linkedin.com/in/harish-chittoor-622283ba/"><br><br><br><br><br><img src="Li.png" alt="LinkedIn" style="width:6%;margin-left:685px"></a>

		<footer><b>All rights reserved @ Harish</b></footer>
	</div>
	<div class="box">
	<img class="close" src="images/close.png" width="30"/>
	<div>
		<p>Perform Captcha</p>
		<div id="droppable">Drop here</div>
		<div id="draggable">Drag me</div>
		<iframe id="my_iframe" style="display:none;"></iframe>
		<script>
$( "#draggable" ).draggable();
$( "#droppable" ).droppable({
  drop: function() {   
  	//window.location.=url;
    // window.open(url, 'download'); 
    window.location.href = 'Resume.pdf';
    }
});
</script>
	</div>
</body>

</html>