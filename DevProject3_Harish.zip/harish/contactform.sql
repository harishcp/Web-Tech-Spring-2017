-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2017 at 12:50 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `harshu_wt_proj`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactform`
--

CREATE TABLE IF NOT EXISTS `contactform` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(128) NOT NULL,
  `message` varchar(500) NOT NULL,
  `roc` varchar(128) NOT NULL,
  `time_stamp` timestamp NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `contactform`
--

INSERT INTO `contactform` (`ID`, `firstname`, `lastname`, `email`, `message`, `roc`, `time_stamp`) VALUES
(1, 'Naga', 'Anurag', 'anurag.beeram7@gmail.com', 'hiii', 'Job Offer', '2017-05-01 22:33:46'),
(2, 'raj', 'mantri', 'raj@gmail.com', 'hiiii', 'SeekInformation', '2017-05-01 22:34:13'),
(3, 'bahu', 'bhali', 'bahubali@rajamouli.com', 'WKKB', 'SeekInformation', '2017-05-01 22:35:03'),
(4, 'shivagami', 'ramyakrishna', 'shivagami@bahubali.com', 'hiiii', 'Job Offer', '2017-05-01 22:35:46'),
(5, 'harish', 'harshu', 'harshu@gmail.com', 'WKKB', 'Maintenance', '2017-05-01 22:36:39'),
(6, 'anushka', 'shetty', 'anushka@bahubali.com', 'hiii', 'Job Offer', '2017-05-01 22:37:16');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
